﻿using Microsoft.Extensions.Configuration;
using SSI.RpaEinvoice.Common.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Common.CustomConfig
{
    public static class ConfigurationRootExtensions
    {
        public static IConfigurationRoot DecryptJsonConfiguration(this IConfigurationRoot configurationRoot)
        {
            HashSet<string> knownArrayKeys = new HashSet<string>();

            foreach (IConfigurationProvider provider in configurationRoot.Providers.Reverse())
            {
                if (provider.GetType().Name == "JsonConfigurationProvider")
                {
                    foreach (var key in GetProviderKeys(provider, null).Reverse())
                    {
                        string value = "";
                        if (provider.TryGet(key, out value))
                        {
                            provider.Set(key, TrippleDESHelper.Decrypt(key, value));
                        }
                    }
                }
            }

            return configurationRoot;
        }

        private static IEnumerable<string> GetProviderKeys(IConfigurationProvider provider, string parentPath)
        {
            var prefix = parentPath == null
                    ? string.Empty
                    : parentPath + ConfigurationPath.KeyDelimiter;

            List<string> keys = new List<string>();
            var childKeys = provider.GetChildKeys(Enumerable.Empty<string>(), parentPath)
                                    .Distinct()
                                    .Select(k => prefix + k).ToList();
            keys.AddRange(childKeys);
            foreach (var key in childKeys)
            {
                keys.AddRange(GetProviderKeys(provider, key));
            }

            return keys;
        }
    }
}
