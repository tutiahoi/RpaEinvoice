﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using SSI.RpaEinvoice.Common.Security;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Common.CustomConfig
{
    /// <summary>Represents a <see cref="ProtectedJsonConfigurationProvider"/> source</summary>
    public class ProtectedJsonConfigurationSource : JsonConfigurationSource
    {
        /// <summary>Represents a <see cref="ProtectedJsonConfigurationProvider"/> source</summary>
        /// <param name="entropy">Byte array to increase protection</param>
        /// <exception cref="ArgumentNullException"/>
        public ProtectedJsonConfigurationSource()
        {

        }

        /// <summary>Builds the configuration provider</summary>
        /// <param name="builder">Builder to build in</param>
        /// <returns>Returns the configuration provider</returns>
        public override IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            EnsureDefaults(builder);
            return new ProtectedJsonConfigurationProvider(this);
        }

    }

    /// <summary>Represents a provider that protects a JSON configuration file</summary>
    public partial class ProtectedJsonConfigurationProvider : JsonConfigurationProvider
    {
        private readonly ProtectedJsonConfigurationSource protectedSource;

        /// <summary>Checks whether the given text is encrypted</summary>
        /// <param name="text">Text to check</param>
        /// <returns>Returns true in case the text is encrypted</returns>
        private bool isEncrypted(string text)
        {
            if (text == null) { return false; }

            return true;
        }

        /// <summary>Represents a provider that protects a JSON configuration file</summary>
        /// <param name="source">Settings of the source</param>
        /// <see cref="ArgumentNullException"/>
        public ProtectedJsonConfigurationProvider(ProtectedJsonConfigurationSource source) : base(source)
        {
            this.protectedSource = source as ProtectedJsonConfigurationSource;
        }

        /// <summary>Loads the JSON data from the given <see cref="Stream"/></summary>
        /// <param name="stream"><see cref="Stream"/> to load</param>
        public override void Load(Stream stream)
        {
            //Call the base method first to ensure the data to be available
            base.Load(stream);


            //Dictionary that contains the keys (and their encrypted value) that must be written to the JSON file
            var encryptedKeyValuesToWrite = new Dictionary<string, string>();

            //Iterate through the data in order to verify whether the keys that require to be encrypted, as indeed encrypted.
            //Copy the keys to a new string array in order to avoid a collection modified exception
            var keys = new string[this.Data.Keys.Count];
            this.Data.Keys.CopyTo(keys, 0);

            foreach (var key in keys)
            {
                //Iterate through each expression in order to check whether the current key must be encrypted and is encrypted.
                //If not then encrypt the value and overwrite the key
                var value = this.Data[key];
                if (!string.IsNullOrEmpty(value))
                {
                    //Verify whether the value is encrypted
                    if (this.isEncrypted(value))
                    {
                        var protectedValue = TrippleDESHelper.Decrypt(key, value);
                        this.Data[key] = protectedValue;
                    }
                }
            }

        }
    }
    /// <summary>Provides extensions concerning <see cref="ProtectedJsonConfigurationProvider"/></summary>
    public static class ProtectedJsonConfigurationProviderExtensions
    {
        /// <summary>Adds a protected JSON file</summary>
        /// <param name="configurationBuilder"><see cref="IConfigurationBuilder"/> in which to apply the JSON file</param>
        /// <param name="path">Path to the JSON file</param>
        /// <param name="optional">Specifies whether the JSON file is optional</param>
        /// <param name="entropy">Byte array to increase protection</param>
        /// <returns>Returns the <see cref="IConfigurationBuilder"/></returns>
        /// <exception cref="ArgumentNullException"/>
        public static IConfigurationBuilder AddProtectedJsonFile(this IConfigurationBuilder configurationBuilder, string path, bool optional)
        {
            var source = new ProtectedJsonConfigurationSource()
            {
                Path = path,
                Optional = optional
            };

            return configurationBuilder.Add(source);
        }
    }
}
