﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Common
{
    public class JsonResultModel<TData>
    {
        public int StatusCode { get; set; } = (int)HttpStatusCode.OK;
        public string Message { get; set; } = "";
        public TData Data { get; set; }

        public JsonResultModel(TData data)
        {
            Data = data;
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }

    class IgnoreResponse { }

    public static class HttpClientExtensions
    {
        public static async Task<JsonResultModel<T>> PostJsonAsync<T>(this HttpClient httpClient, string requestUri, object content)
            where T : new()
        {
            HttpStatusCode resHttpStatusCode = HttpStatusCode.InternalServerError;
            try
            {
                //Accept all server certificate
                //ServicePointManager.ServerCertificateValidationCallback =
                //    delegate (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
                //    {
                //        return true;
                //    };

                var contentJson = JsonConvert.SerializeObject(content);
                var response = await httpClient.SendAsync(new HttpRequestMessage(HttpMethod.Post, requestUri)
                {
                    Content = new StringContent(contentJson.ToString(), Encoding.UTF8, "application/json")
                });
                resHttpStatusCode = response.StatusCode;
                //response.EnsureSuccessStatusCode();

                if (typeof(JsonResultModel<T>) == typeof(IgnoreResponse))
                {
                    return default;
                }
                else
                {
                    var text = await response.Content.ReadAsStringAsync();
                    var resData = JsonConvert.DeserializeObject<T>(text, new JsonSerializerSettings() { });
                    var resultModel = new JsonResultModel<T>(resData);
                    resultModel.StatusCode = (int)resHttpStatusCode;
                    resultModel.Message = resHttpStatusCode.ToString();
                    return resultModel;
                }
            }
            catch (Exception ex)
            {
                var result = new JsonResultModel<T>(default);
                result.StatusCode = (int)resHttpStatusCode;
                result.Message = ex.Message;
                return result;
            }

        }

        public static async Task<JsonResultModel<T>> PostJsonAsync<T>(this HttpClient httpClient, string requestUri, string contentJson)
            where T : new()
        {
            HttpStatusCode resHttpStatusCode = HttpStatusCode.InternalServerError;
            try
            {                
                var response = await httpClient.SendAsync(new HttpRequestMessage(HttpMethod.Post, requestUri)
                {
                    Content = new StringContent(contentJson.ToString(), Encoding.UTF8, "application/json")
                });
                resHttpStatusCode = response.StatusCode;
                //response.EnsureSuccessStatusCode();

                if (typeof(JsonResultModel<T>) == typeof(IgnoreResponse))
                {
                    return default;
                }
                else
                {
                    var text = await response.Content.ReadAsStringAsync();
                    var resData = JsonConvert.DeserializeObject<T>(text, new JsonSerializerSettings() { });
                    var resultModel = new JsonResultModel<T>(resData);
                    resultModel.StatusCode = (int)resHttpStatusCode;
                    resultModel.Message = resHttpStatusCode.ToString();
                    return resultModel;
                }
            }
            catch (Exception ex)
            {
                var result = new JsonResultModel<T>(default);
                result.StatusCode = (int)resHttpStatusCode;
                result.Message = ex.Message;
                return result;
            }

        }

        public static void SetHeader(this HttpClient httpClient, HttpMethod httpMethod, string user, string pass)
        {
            var key = Util.GenerateToken(httpMethod.Method, user, pass);
            httpClient.DefaultRequestHeaders.Add("Authentication", key);
        }

        public static void SetTimeout(this HttpClient httpClient, TimeSpan timeSpan)
        {
            httpClient.Timeout = timeSpan;
        }
    }
}
