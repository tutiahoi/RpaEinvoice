﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Common
{
    public static class Util
    {
        //public static string GenerateToken(string httpMethod, string username, string password)
        //{
        //    DateTime epochStart = new DateTime(1970, 01, 01, 0, 0, 0, 0, DateTimeKind.Utc);
        //    TimeSpan timeSpan = DateTime.UtcNow - epochStart;
        //    string timestamp = Convert.ToUInt64(timeSpan.TotalSeconds).ToString();
        //    string nonce = Guid.NewGuid().ToString("N").ToLower();
        //    string signatureRawData = $"{httpMethod.ToUpper()}{timestamp}{nonce}";

        //    using (MD5 md5 = MD5.Create())
        //    {
        //        var hash = md5.ComputeHash(Encoding.UTF8.GetBytes(signatureRawData));
        //        var signature = Convert.ToBase64String(hash);
        //        return $"{signature}:{nonce}:{timestamp}:{username}:{password}";
        //    }
        //}

        public static string GenerateToken(string httpMethod, string username, string password)
        {
            DateTime epochStart = new DateTime(1970, 01, 01, 0, 0, 0, 0, DateTimeKind.Utc);
            TimeSpan timeSpan = DateTime.UtcNow - epochStart;
            string timestamp = Convert.ToUInt64(timeSpan.TotalSeconds).ToString();
            string nonce = Guid.NewGuid().ToString("N").ToLower();
            string signatureRawData = string.Format("{0}{1}{2}", httpMethod.ToUpper(), timestamp, nonce);            
            using (SHA256 shH256 = SHA256.Create())
            {
                var hash = shH256.ComputeHash(Encoding.UTF8.GetBytes(signatureRawData));
                var signature = Convert.ToBase64String(hash);
                return string.Format("{0}:{1}:{2}:{3}:{4}", signature, nonce, timestamp, username, password);
            }
        }
    }
}
