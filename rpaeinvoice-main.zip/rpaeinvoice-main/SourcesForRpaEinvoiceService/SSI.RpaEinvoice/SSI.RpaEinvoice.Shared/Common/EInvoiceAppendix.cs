﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.Common
{
    public static class ResStatusCode
    {
        //Invoice
        public const string SuccessCode = "2";
        public const string ClientErrorCode = "4";
        public const string ServerErrorCode = "5";

        //Details
        public const string ErrorCodeERR1 = "ERR1:";
        public const string ErrorCodeERR2 = "ERR2:";
        public const string ErrorCodeERR3a = "ERR3a:";
    }    
}
