﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.Domain
{
    public class API_INV_GetBranch
    {
        public string BranchID { get; set; }
        public string BranchName { get; set; }
        public string Url { get; set; }        
    }
}
