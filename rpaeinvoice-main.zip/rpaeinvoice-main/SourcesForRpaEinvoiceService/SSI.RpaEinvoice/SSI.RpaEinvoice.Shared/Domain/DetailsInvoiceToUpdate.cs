﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.Domain
{
    public class DetailsInvoiceToUpdate
    {
        public string Ikey { get; set; } = "";
        public bool Status { get; set; }
        public string ErrorCode { get; set; } = "";
        public string ErrorMsg { get; set; } = "";
    }
}
