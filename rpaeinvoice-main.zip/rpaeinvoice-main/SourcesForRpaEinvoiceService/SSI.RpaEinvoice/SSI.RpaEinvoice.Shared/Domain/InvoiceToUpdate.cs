﻿using SSI.RpaEinvoice.Shared.EInvoiceEntites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.Domain
{
    public class InvoiceToUpdate:InvoiceRes
    {
        public string Message { get; set; } = "";
        public int ErrorCode { get; set; }
        public string Status { get; set; } = "";
        public string ErrorMsg { get; set; } = "";
    }
}
