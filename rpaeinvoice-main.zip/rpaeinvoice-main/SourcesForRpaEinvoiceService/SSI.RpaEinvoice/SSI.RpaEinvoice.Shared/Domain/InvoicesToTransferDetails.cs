﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.Domain
{
    public class InvoicesToTransferDetails
    {
        public string Json_Output { get; set; }
        public string Url { get; set; }
        public string Pattern { get; set; }
        public string Serial { get; set; }
        public string TaxCode { get; set; }
    }
}
