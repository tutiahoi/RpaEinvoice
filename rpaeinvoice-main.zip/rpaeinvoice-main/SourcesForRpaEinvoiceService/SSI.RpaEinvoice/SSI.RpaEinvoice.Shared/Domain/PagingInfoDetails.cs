﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.Domain
{
    public class PagingInfoDetails
    {
        public string BranchID { get; set; }
        public int RowsOfPage { get; set; }
        public int TotPage { get; set; }
        public int TotRow { get; set; }
    }
}
