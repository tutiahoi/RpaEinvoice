﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.Domain
{
    public class UpdateStatusInvoiceRes
    {
        public string ErrorName { get; set; }
        public int ErrorStatus { get; set; }
    }
}
