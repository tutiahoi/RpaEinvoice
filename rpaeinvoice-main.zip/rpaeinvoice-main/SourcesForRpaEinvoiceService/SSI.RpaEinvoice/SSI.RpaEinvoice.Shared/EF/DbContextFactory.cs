﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

namespace SSI.RpaEinvoice.Shared.EF
{
    public class DbContextFactory
    {
        private readonly IConfiguration _configuration;
        private readonly string connectionString;
        private readonly int timeout;
        public DbContextFactory(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = _configuration.GetConnectionString("RPAConnection");
            timeout = _configuration.GetValue<int>("SqlDbContext:CommandTimeout");
        }

        public RPAContext Create()
        {
            var options = new DbContextOptionsBuilder<RPAContext>()
                .UseSqlServer(connectionString,
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.CommandTimeout(timeout);
                        sqlOptions.EnableRetryOnFailure(
                            maxRetryCount: 3,
                            maxRetryDelay: TimeSpan.FromSeconds(30),
                            errorNumbersToAdd: null);
                    })
                .Options;

            return new RPAContext(options);
        }
    }
}
