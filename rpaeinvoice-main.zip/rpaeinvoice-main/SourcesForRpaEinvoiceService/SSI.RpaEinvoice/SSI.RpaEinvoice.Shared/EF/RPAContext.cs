﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using SSI.RpaEinvoice.Shared.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.EF
{
    public class RPAContext : DbContext
    {
        public RPAContext() : base() { }
        public RPAContext(DbContextOptions<RPAContext> options) : base(options)
        {
            ChangeTracker.LazyLoadingEnabled = false;
            ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }

        public DbSet<API_INV_GetBranch> API_INV_GetBranch { get; set; }
        public DbSet<ActionImportInvoicesFlag> ActionImportInvoicesFlags { get; set; }
        public DbSet<PagingInfo> PagingInfo { get; set; }
        public DbSet<InvoicesToTransfer> InvoicesToTransfer { get; set; }
        public DbSet<UpdateStatusInvoiceRes> UpdateStatusInvoiceRes { get; set; }

        public DbSet<ActionImportInvoicesDetailsFlag> ActionImportInvoicesDetailsFlags { get; set; }
        public DbSet<PagingInfoDetails> PagingInfoDetails { get; set; }
        public DbSet<InvoicesToTransferDetails> InvoicesToTransferDetails { get; set; }
        public DbSet<UpdateStatusInvoiceDetailsRes> UpdateStatusInvoiceDetailsRes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.EnableSensitiveDataLogging();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<API_INV_GetBranch>().HasNoKey();

            modelBuilder.Entity<ActionImportInvoicesFlag>().HasNoKey();
            modelBuilder.Entity<PagingInfo>().HasNoKey();
            modelBuilder.Entity<InvoicesToTransfer>().HasNoKey();
            modelBuilder.Entity<UpdateStatusInvoiceRes>().HasNoKey();

            modelBuilder.Entity<ActionImportInvoicesDetailsFlag>().HasNoKey();
            modelBuilder.Entity<PagingInfoDetails>().HasNoKey();
            modelBuilder.Entity<InvoicesToTransferDetails>().HasNoKey();
            modelBuilder.Entity<UpdateStatusInvoiceDetailsRes>().HasNoKey();
        }        
    }
}
