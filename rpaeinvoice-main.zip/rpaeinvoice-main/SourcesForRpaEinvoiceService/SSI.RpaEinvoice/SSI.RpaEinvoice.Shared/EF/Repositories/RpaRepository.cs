﻿using Microsoft.EntityFrameworkCore;
using SSI.RpaEinvoice.Shared.Domain;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NLog.Web;
using NLog;
using Microsoft.Extensions.Configuration;

namespace SSI.RpaEinvoice.Shared.EF.Repositories
{
    public interface IRpaRepository
    {
        Task<List<API_INV_GetBranch>> GetBranchList();

        #region Hóa đơn
        Task<ActionImportInvoicesFlag> GetActionFlag(int month, int year);
        Task<PagingInfo> GetPagingInfo(int month, int year, string branchId);
        Task<InvoicesToTransfer> GetInvoicesToTransfer(int month, int year, string branchId, int rowsOfPage, int pageNumber);
        Task<UpdateStatusInvoiceRes> UpdateInvoice(int month, int year, string ikey, string status, string message, string errorCode, string invoiceStatus, string pattern, string serial, string no, string lookupCode, string arisingDate, string issueDate, string errorMsg);

        #endregion

        #region Bảng kê
        Task<ActionImportInvoicesDetailsFlag> GetActionDetailsFlag(int month, int year);
        Task<PagingInfoDetails> GetPagingInfoDetails(int month, int year, string branchId);
        Task<InvoicesToTransferDetails> GetInvoicesToTransferDetails(int month, int year, string branchId, int rowsOfPage, int pageNumber);
        Task<UpdateStatusInvoiceDetailsRes> UpdateInvoiceDetails(int month, int year, string ikey, bool status, string errorCode, string errorMsg);
        #endregion

    }

    public class RpaRepository : IRpaRepository
    {
        private readonly DbContextFactory _dbContextFactory;
        private Logger logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

        public RpaRepository(DbContextFactory dbContextFactory)
        {
            _dbContextFactory = dbContextFactory;
        }

        public async Task<List<API_INV_GetBranch>> GetBranchList()
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var res = context.API_INV_GetBranch.ToList();
                    return res;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }

        #region Hóa đơn
        public async Task<ActionImportInvoicesFlag> GetActionFlag(int month, int year)
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var Month = new SqlParameter("@Month", month);
                    var Year = new SqlParameter("@Year", year);
                    var res = context.ActionImportInvoicesFlags.FromSqlRaw($"EXECUTE API_INV_ActionImportInvoices @Month, @Year", Month, Year).AsEnumerable().FirstOrDefault();
                    return res;
                }

            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }

        public async Task<InvoicesToTransfer> GetInvoicesToTransfer(int month, int year, string branchId, int rowsOfPage, int pageNumber)
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var Month = new SqlParameter("@Month", month);
                    var Year = new SqlParameter("@Year", year);
                    var BranchID = new SqlParameter("@BranchID", branchId);
                    var RowsOfPage = new SqlParameter("@RowsOfPage", rowsOfPage);
                    var PageNumber = new SqlParameter("@PageNumber", pageNumber);

                    var res = context.InvoicesToTransfer.FromSqlRaw($"EXECUTE API_INV_GetInvoicesToTransfer @Month, @Year, @BranchID, @RowsOfPage, @PageNumber", Month, Year, BranchID, RowsOfPage, PageNumber).AsEnumerable().FirstOrDefault();
                    return res;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }

        public async Task<PagingInfo> GetPagingInfo(int month, int year, string branchId)
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var Month = new SqlParameter("@Month", month);
                    var Year = new SqlParameter("@Year", year);
                    var BranchID = new SqlParameter("@BranchID", branchId);

                    var res = context.PagingInfo.FromSqlRaw($"EXECUTE API_INV_GetPagingInfo @Month, @Year, @BranchID", Month, Year, BranchID).AsEnumerable().FirstOrDefault();
                    return res;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }

        public async Task<UpdateStatusInvoiceRes> UpdateInvoice(int month, int year, string ikey, string status, string message, string errorCode, string invoiceStatus, string pattern, string serial, string no, string lookupCode, string arisingDate, string issueDate, string errorMsg)
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var Month = new SqlParameter("@Month", month);
                    var Year = new SqlParameter("@Year", year);
                    var Ikey = new SqlParameter("@Ikey", ikey);
                    var Status = new SqlParameter("@Status", status);
                    var Message = new SqlParameter("@Message", message);
                    var ErrorCode = new SqlParameter("@ErrorCode", errorCode);
                    var InvoiceStatus = new SqlParameter("@InvoiceStatus", invoiceStatus);
                    var Pattern = new SqlParameter("@Pattern", pattern);
                    var Serial = new SqlParameter("@Serial", serial);
                    var No = new SqlParameter("@No", no);
                    var LookupCode = new SqlParameter("@LookupCode", lookupCode);
                    var ArisingDate = new SqlParameter("@ArisingDate", string.IsNullOrEmpty(arisingDate) ? DBNull.Value : DateTime.ParseExact(arisingDate, "dd/MM/yyyy", null));
                    var IssueDate = new SqlParameter("@IssueDate", string.IsNullOrEmpty(issueDate) ? DBNull.Value : DateTime.ParseExact(issueDate, "dd/MM/yyyy", null));
                    var ErrorMsg = new SqlParameter("@ErrorMsg", errorMsg);

                    var res = context.UpdateStatusInvoiceRes.FromSqlRaw($"EXECUTE API_INV_UpdateStatusInvoice @Month, @Year, @Ikey, @Status, @Message, @ErrorCode, @InvoiceStatus, @Pattern, @Serial, @No, @LookupCode, @ArisingDate, @IssueDate, @ErrorMsg", Month, Year, Ikey, Status, Message, ErrorCode, InvoiceStatus, Pattern, Serial, No, LookupCode, ArisingDate, IssueDate, ErrorMsg).AsEnumerable().FirstOrDefault();

                    return res;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }
        #endregion

        #region Bảng kê
        public async Task<ActionImportInvoicesDetailsFlag> GetActionDetailsFlag(int month, int year)
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var Month = new SqlParameter("@Month", month);
                    var Year = new SqlParameter("@Year", year);
                    var res = context.ActionImportInvoicesDetailsFlags.FromSqlRaw($"EXECUTE API_INV_ActionImportInvoices_Detail @Month, @Year", Month, Year).AsEnumerable().FirstOrDefault();
                    return res;
                }

            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }

        public async Task<PagingInfoDetails> GetPagingInfoDetails(int month, int year, string branchId)
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var Month = new SqlParameter("@Month", month);
                    var Year = new SqlParameter("@Year", year);
                    var BranchID = new SqlParameter("@BranchID", branchId);

                    var res = context.PagingInfoDetails.FromSqlRaw($"EXECUTE API_INV_GetPagingInfo_Detail @Month, @Year, @BranchID", Month, Year, BranchID).AsEnumerable().FirstOrDefault();
                    return res;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }

        public async Task<InvoicesToTransferDetails> GetInvoicesToTransferDetails(int month, int year, string branchId, int rowsOfPage, int pageNumber)
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var Month = new SqlParameter("@Month", month);
                    var Year = new SqlParameter("@Year", year);
                    var BranchID = new SqlParameter("@BranchID", branchId);
                    var RowsOfPage = new SqlParameter("@RowsOfPage", rowsOfPage);
                    var PageNumber = new SqlParameter("@PageNumber", pageNumber);

                    var res = context.InvoicesToTransferDetails.FromSqlRaw($"EXECUTE API_INV_GetInvoicesToTransfer_Detail @Month, @Year, @BranchID, @RowsOfPage, @PageNumber", Month, Year, BranchID, RowsOfPage, PageNumber).AsEnumerable().FirstOrDefault();
                    return res;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }

        public async Task<UpdateStatusInvoiceDetailsRes> UpdateInvoiceDetails(int month, int year, string ikey, bool status, string errorCode, string errorMsg)
        {
            try
            {
                using (var context = _dbContextFactory.Create())
                {
                    var Month = new SqlParameter("@Month", month);
                    var Year = new SqlParameter("@Year", year);
                    var Ikey = new SqlParameter("@Ikey", ikey);
                    var Status = new SqlParameter("@Status", status);
                    var ErrorCode = new SqlParameter("@ErrorCode", string.IsNullOrEmpty(errorCode) ? DBNull.Value : errorCode);
                    var ErrorMsg = new SqlParameter("@ErrorMsg", string.IsNullOrEmpty(errorMsg) ? DBNull.Value : errorMsg);

                    var res = context.UpdateStatusInvoiceDetailsRes.FromSqlRaw($"EXECUTE API_INV_UpdateStatusInvoice_Detail @Month, @Year, @Ikey, @Status, @ErrorCode, @ErrorMsg", Month, Year, Ikey, Status, ErrorCode, ErrorMsg).AsEnumerable().FirstOrDefault();

                    return res;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return null;
            }
        }


        #endregion


    }
}
