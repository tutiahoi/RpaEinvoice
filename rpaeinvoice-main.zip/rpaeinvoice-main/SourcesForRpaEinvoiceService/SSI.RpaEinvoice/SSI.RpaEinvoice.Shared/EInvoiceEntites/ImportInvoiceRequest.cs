﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.EInvoiceEntites
{
    public class ImportInvoiceRequest
    {
        public string XmlData { get; set; }
        public string Pattern { get; set; }
        public string Serial { get; set; }
    }
}
