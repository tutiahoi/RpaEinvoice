﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoice.Shared.EInvoiceEntites
{
    public class ImportInvoiceRes
    {
        public string Status { get; set; } = "";
        public string Message { get; set; } = "";
        public int ErrorCode { get; set; }

        public DataRes Data { get; set; }
    }

    public class DataRes
    {
        public string Pattern { get; set; } = "";
        public string Serial { get; set; } = "";
        public List<string> Ikeys { get; set; }
        public List<InvoiceRes> Invoices { get; set; }
        public IDictionary<string, string> KeyInvoiceMsg { get; set; }
    }

    public class InvoiceRes
    {
        public int InvoiceStatus { get; set; }
        public string Buyer { get; set; } = "";
        public decimal TaxAmount { get; set; }
        public string PublishedBy { get; set; } = "";
        public string Pattern { get; set; } = "";
        public string Serial { get; set; } = "";
        public string No { get; set; } = "";
        public string Ikey { get; set; } = "";
        public string ArisingDate { get; set; } = "";
        public string IssueDate { get; set; } = "";
        public string CustomerName { get; set; } = "";
        public string CustomerAddress { get; set; } = "";
        public string CustomerCode { get; set; } = "";
        public string CustomerTaxCode { get; set; } = "";
        public decimal Total { get; set; }
        public decimal Amount { get; set; }
        public string LookupCode { get; set; } = "";
        public string LinkView { get; set; } = "";
        public string ModifiedDate { get; set; } = "";
        public bool IsSentTCTSummary { get; set; }
        public string TCTCheckStatus { get; set; } = "";
        public string TCTErrorMessage { get; set; } = "";
        public string TaxAuthorityCode { get; set; } = "";
    }
}
