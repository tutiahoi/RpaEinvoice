﻿using SSI.RpaEinvoice.Shared.Domain;
using SSI.RpaEinvoice.Shared.EInvoiceEntites;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RpaEinvoiceService
{
    public static class DataStorage
    {
        public static ConcurrentDictionary<string, bool> MonitorProcessInvoice = new ConcurrentDictionary<string, bool>();
        public static ConcurrentDictionary<string, bool> MonitorProcessDetails = new ConcurrentDictionary<string, bool>();
        public static ConcurrentQueue<InvoiceToUpdate> IkeyInvoices = new ConcurrentQueue<InvoiceToUpdate>();
        public static ConcurrentQueue<DetailsInvoiceToUpdate> IkeyDetailsInvoices = new ConcurrentQueue<DetailsInvoiceToUpdate>();
        public static int ActionMonth = DateTime.Now.AddMonths(-1).Month;
        public static int ActionYear = DateTime.Now.AddMonths(-1).Year;

        public static void UpdateMonitorProcessInvoice(string branchID, bool isOnProcess)
        {
            MonitorProcessInvoice.AddOrUpdate(branchID, isOnProcess, delegate { return isOnProcess; });
        }

        public static void UpdateMonitorProcessDetails(string branchID, bool isOnProcess)
        {
            MonitorProcessDetails.AddOrUpdate(branchID, isOnProcess, delegate { return isOnProcess; });
        }

        public static bool IsOnMonitorProcessInvoice()
        {
            var isOnProcess = (MonitorProcessInvoice.Any() && MonitorProcessInvoice.Any(x => x.Value)) || IkeyInvoices.Any();
            return isOnProcess;
        }

        public static bool IsOnMonitorProcessDetails()
        {
            var isOnProcess = MonitorProcessDetails.Any() && MonitorProcessDetails.Any(x => x.Value);
            return isOnProcess;
        }
    }
}
