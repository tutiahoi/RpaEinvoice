﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ServiceProcess;
using Newtonsoft.Json;
using Microsoft.Extensions.DependencyInjection;
using NLog;
using NLog.Web;
using SSI.RpaEinvoiceService.Services;
using System.Threading;
using SSI.RpaEinvoice.Common.CustomConfig;

namespace SSI.RpaEinvoiceService
{
    public static class Program
    {
        static void Main(string[] args)
        {
            using (var service = new RpaEinvoiceServiceBE())
            {
                ServiceBase.Run(service);
            }
        }

        internal class RpaEinvoiceServiceBE : ServiceBase
        {
            IConfigurationRoot config = new ConfigurationBuilder().AddProtectedJsonFile("appsettings.json", true).Build();
            private Logger logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

            private List<TimerServiceRealtime> lstRealtimeServices = new List<TimerServiceRealtime>();
            IServiceCollection services = new ServiceCollection();
            private IServiceProvider serviceProvider;

            public RpaEinvoiceServiceBE()
            {
                ServiceName = "SSI.RpaEinvoiceServicesBE";
            }

            protected override void OnStart(string[] args)
            {
                logger.Info($"{DateTime.Now} started.{Environment.NewLine}");
                var startup = new Startup();
                startup.ConfigureServices(services);
                serviceProvider = services.BuildServiceProvider();

                var iInvoiceService = serviceProvider.GetService<IInvoiceService>();
                (new Thread(() => iInvoiceService.MonitorRes())).Start();

                var iDetailsInvoiceService = serviceProvider.GetService<IDetailsInvoiceService>();
                (new Thread(() => iDetailsInvoiceService.MonitorRes())).Start();

                var valuesSection = config.GetSection("JobConfig:Values");
                try
                {
                    foreach (IConfigurationSection section in valuesSection.GetChildren())
                    {
                        if (section.GetValue<string>("JobName") == "MonitorImportInvoiceFlag")
                        {
                            TimerServiceRealtime timer = new TimerServiceRealtime(section.GetValue<string>("JobName"),
                                                                            section.GetValue<bool>("Enable"),
                                                                            section.GetValue<string>("Time.Start"),
                                                                            section.GetValue<string>("Time.End"),
                                                                            section.GetValue<int>("Interval"),
                                                                            section.GetValue<bool>("RunImmediate"),
                                                                            serviceProvider.GetService<IInvoiceService>(), serviceProvider.GetService<IDetailsInvoiceService>());
                            logger.Info("JobStart: " + section.GetValue<string>("JobName"));
                            lstRealtimeServices.Add(timer);
                        }
                        else if (section.GetValue<string>("JobName") == "MonitorImportInvoiceDetailsFlag")
                        {
                            TimerServiceRealtime timer = new TimerServiceRealtime(section.GetValue<string>("JobName"),
                                                                            section.GetValue<bool>("Enable"),
                                                                            section.GetValue<string>("Time.Start"),
                                                                            section.GetValue<string>("Time.End"),
                                                                            section.GetValue<int>("Interval"),
                                                                            section.GetValue<bool>("RunImmediate"),
                                                                            serviceProvider.GetService<IInvoiceService>(), serviceProvider.GetService<IDetailsInvoiceService>());
                            logger.Info("JobStart: " + section.GetValue<string>("JobName"));
                            lstRealtimeServices.Add(timer);
                        }
                    }
                }
                catch (Exception ex)
                {
                    logger.Error("Exception " + ex.Message + $"\n detail: {JsonConvert.SerializeObject(ex)}");
                }

            }

            protected override void OnStop()
            {
                logger.Info($"{DateTime.Now} stopped.{Environment.NewLine}");
                if (lstRealtimeServices != null)
                {
                    foreach (TimerServiceRealtime timer in lstRealtimeServices)
                    {
                        timer.Disponse();
                    }
                    lstRealtimeServices.Clear();
                }
            }
        }
    }
}
