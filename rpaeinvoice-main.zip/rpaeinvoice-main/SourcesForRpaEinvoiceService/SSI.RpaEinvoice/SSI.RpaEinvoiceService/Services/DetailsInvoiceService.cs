﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLog;
using NLog.Web;
using SSI.RpaEinvoice.Shared.Common;
using SSI.RpaEinvoice.Shared.Domain;
using SSI.RpaEinvoice.Shared.EF.Repositories;
using SSI.RpaEinvoice.Shared.EInvoiceEntites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SSI.RpaEinvoiceService.Services
{
    public class DetailsInvoiceService : IDetailsInvoiceService
    {
        private readonly IRpaRepository _rpaRepository;
        private readonly IEInvoiceWebService _eInvoiceWebService;
        private Logger logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

        public DetailsInvoiceService(IRpaRepository rpaRepository, IEInvoiceWebService eInvoiceWebService)
        {
            _rpaRepository = rpaRepository;
            _eInvoiceWebService = eInvoiceWebService;
        }

        private async Task<List<API_INV_GetBranch>> GetBranches()
        {
            try
            {
                var res = await _rpaRepository.GetBranchList();
                return res;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
            return null;
        }

        public async Task ProcessData()
        {
            var year = DateTime.Now.AddMonths(-1).Year;
            var month = DateTime.Now.AddMonths(-1).Month;            
            DataStorage.ActionMonth = month;
            DataStorage.ActionYear = year;

            if (!DataStorage.IsOnMonitorProcessDetails())
            {
                var flag = await GetDetailInvoiceFlag(DataStorage.ActionMonth, DataStorage.ActionYear);
                if(flag)
                {
                    var lstBranch = await GetBranches();
                    if (lstBranch != null && lstBranch.Any())
                    {
                        foreach (var branch in lstBranch)
                        {
                            (new Thread(() => ProcessBranchDataDetails(branch.BranchID, month, year))).Start();
                        }
                    }
                }
                else
                {
                    logger.Info("The detail flag is FALSE!");
                }                
            }
            else
            {
                logger.Info("Previous process is running!");
            }
        }

        private async Task<bool> GetDetailInvoiceFlag(int month, int year)
        {
            try
            {
                var res = await _rpaRepository.GetActionDetailsFlag(month, year);
                return res.Flag;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
            return false;
        }

        private async Task<PagingInfoDetails> GetPagingInfoDetails(string branchId, int month, int year)
        {
            try
            {
                var res = await _rpaRepository.GetPagingInfoDetails(month, year, branchId);
                return res;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
            return null;
        }

        private async Task<InvoicesToTransferDetails> GetDetailsToTransfer(string branchID, int month, int year, int rowsOfPage, int page)
        {
            try
            {
                var res = await _rpaRepository.GetInvoicesToTransferDetails(month, year, branchID, rowsOfPage, page);
                return res;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
            return null;
        }

        public async Task SendDataDetailsToInvoice(InvoicesToTransferDetails data, int page, PagingInfoDetails pagingInfo)
        {
            var res = await _eInvoiceWebService.SendImportInvoiceDetails(pagingInfo, page, data.Url, data.TaxCode, new ImportInvoiceDetailsRequest()
            {
                JsonData = data.Json_Output
            });

            if (res != null)
            {
                if (res.Success || (!res.Success && res.Code == ResStatusCode.ErrorCodeERR1))
                {
                    Dictionary<string, string> iKeyDict = JsonConvert.DeserializeObject<Dictionary<string, string>>(res.Message);

                    foreach (var invoice in iKeyDict)
                    {
                        var detailsInvoiceToUpdate = new DetailsInvoiceToUpdate();
                        detailsInvoiceToUpdate.Ikey = invoice.Key;
                        detailsInvoiceToUpdate.ErrorMsg = invoice.Value;
                        detailsInvoiceToUpdate.ErrorCode = res.Code;
                        detailsInvoiceToUpdate.Status = res.Success;
                        DataStorage.IkeyDetailsInvoices.Enqueue(detailsInvoiceToUpdate);
                    }
                }

                logger.Info($"Details response from EInvoice with data {JsonConvert.SerializeObject(pagingInfo)}:page={page} is {JsonConvert.SerializeObject(res)}");
            }
        }

        private async void ProcessBranchDataDetails(string branchID, int month, int year)
        {
            try
            {
                var pagingInfo = await GetPagingInfoDetails(branchID, month, year);
                if (pagingInfo != null && pagingInfo.RowsOfPage > 0)
                {
                    DataStorage.UpdateMonitorProcessDetails(branchID, true);
                    for (int i = 1; i <= pagingInfo.TotPage; i++)
                    {
                        var data = await GetDetailsToTransfer(branchID, month, year, pagingInfo.RowsOfPage, i);
                        if (data != null && !string.IsNullOrEmpty(data.Json_Output))
                        {
                            await SendDataDetailsToInvoice(data, i, pagingInfo);
                        }
                    }
                    DataStorage.UpdateMonitorProcessDetails(branchID, false);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
        }

        public async Task MonitorRes()
        {
            while (true)
            {
                try
                {
                    DetailsInvoiceToUpdate invoiceDetails;
                    DataStorage.IkeyDetailsInvoices.TryDequeue(out invoiceDetails);
                    if (invoiceDetails != null)
                    {
                        await UpdateDetailsInvoiceToDB(invoiceDetails);
                    }
                    else
                    {
                        Thread.Sleep(1000);
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(ex.Message.ToString());
                }
            }
        }

        private async Task<UpdateStatusInvoiceDetailsRes> UpdateDetailsInvoiceToDB(DetailsInvoiceToUpdate invoiceDetails)
        {
            int retry = 1;
            bool updateSuccess = false;
            do
            {
                try
                {
                    var res = await _rpaRepository.UpdateInvoiceDetails(
                    DataStorage.ActionMonth,
                    DataStorage.ActionYear,
                    invoiceDetails.Ikey,
                    invoiceDetails.Status,
                    invoiceDetails.ErrorCode,
                    invoiceDetails.ErrorMsg);

                    if (res == null)
                    {
                        retry++;
                        Thread.Sleep(1000);
                    }
                    else
                    {
                        updateSuccess = true;
                        logger.Info($"Time: {retry}: Update details ikey {invoiceDetails.Ikey} res: {JsonConvert.SerializeObject(res)}");
                        return res;
                    }
                }
                catch (Exception ex)
                {                    
                    logger.Error(ex.ToString);
                    logger.Info($"Time: {retry}: Update details ikey {invoiceDetails.Ikey} res: {ex.ToString}");
                }

            } while (retry <= 3 && !updateSuccess);

            return null;
        }
    }

    public interface IDetailsInvoiceService
    {
        Task ProcessData();
        Task MonitorRes();
    }
}
