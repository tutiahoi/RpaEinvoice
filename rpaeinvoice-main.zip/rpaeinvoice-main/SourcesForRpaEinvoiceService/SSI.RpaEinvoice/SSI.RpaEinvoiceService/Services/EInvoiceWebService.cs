﻿using Microsoft.Extensions.Configuration;
using NLog;
using NLog.Web;
using SSI.RpaEinvoice.Shared.EInvoiceEntites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using SSI.RpaEinvoice.Common;
using Newtonsoft.Json;
using System.Net;
using SSI.RpaEinvoice.Shared.Domain;
using System.Threading;

namespace SSI.RpaEinvoiceService.Services
{
    public class EInvoiceWebService : IEInvoiceWebService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private Logger logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();
        private IConfiguration _config;        
        private string username;
        private string password;
        private int timeout;

        public EInvoiceWebService(IHttpClientFactory httpClientFactory, IConfiguration config)
        {
            _config = config;            
            username = _config.GetValue<string>("EInvoiceUsername");
            password = _config.GetValue<string>("EInvoicePassword");
            timeout = _config.GetValue<int>("EInvoiceTimeout");
            _httpClientFactory = httpClientFactory;
        }

        public async Task<ImportInvoiceRes> SendImportInvoice(PagingInfo pagingInfo, int page, string url, string taxCode, ImportInvoiceRequest requestData)
        {
            try
            {
                int retry = 1;
                bool sendSuccess = false;
                do
                {
                    logger.Info($"Time {retry}: Request to EInvoice with data: {JsonConvert.SerializeObject(pagingInfo)}:page={page}, DataXML={JsonConvert.SerializeObject(requestData)}");
                    var httpClient = _httpClientFactory.CreateClient();
                    httpClient.SetTimeout(TimeSpan.FromMinutes(timeout));
                    httpClient.DefaultRequestHeaders.Add("TaxCode", taxCode);
                    httpClient.SetHeader(HttpMethod.Post, username, password);
                    var result = await httpClient.PostJsonAsync<ImportInvoiceRes>(url, requestData);
                    logger.Info($"Time {retry}: Response from EInvoice with data {JsonConvert.SerializeObject(pagingInfo)}:page={page} is: StatusCode: {result.StatusCode}, Message: {result.Message}");
                    if (result.Data == null || (result.Data != null && result.Data.Data == null))
                    {
                        retry++;
                        Thread.Sleep(1000);
                    }
                    else
                    {
                        sendSuccess = true;
                        return result.Data;

                    }
                } while (retry <= 3 && !sendSuccess);

                return null;
            }
            catch (Exception ex)
            {
                logger.Error(ex.ToString());
                logger.Error($"Response from EInvoice with data {JsonConvert.SerializeObject(pagingInfo)}:page={page} is: {ex.Message}");
                return null;
            }
        }

        public async Task<ImportInvoiceDetailsRes> SendImportInvoiceDetails(PagingInfoDetails pagingInfo, int page, string url, string taxCode, ImportInvoiceDetailsRequest requestData)
        {
            try
            {
                int retry = 1;
                bool sendSuccess = false;
                do
                {
                    logger.Info($"Time {retry}: Details request to EInvoice with data: {JsonConvert.SerializeObject(pagingInfo)}:page={page}, JsonData={JsonConvert.SerializeObject(requestData)}");
                    var httpClient = _httpClientFactory.CreateClient();
                    httpClient.SetTimeout(TimeSpan.FromMinutes(timeout));
                    httpClient.DefaultRequestHeaders.Add("TaxCode", taxCode);
                    httpClient.SetHeader(HttpMethod.Post, username, password);
                    var result = await httpClient.PostJsonAsync<ImportInvoiceDetailsRes>(url, requestData.JsonData);
                    logger.Info($"Time {retry}: Details response from EInvoice with data {JsonConvert.SerializeObject(pagingInfo)}:page={page} is: StatusCode: {result.StatusCode}, Message: {result.Message}");
                    if (result.Data == null)
                    {
                        retry++;
                        Thread.Sleep(1000);
                    }
                    else
                    {
                        sendSuccess = true;
                        return result.Data;

                    }
                } while (retry <= 3 && !sendSuccess);

                return null;
            }
            catch (Exception ex)
            {
                logger.Error(ex.ToString());
                logger.Error($"Details response from EInvoice with data {JsonConvert.SerializeObject(pagingInfo)}:page={page} is: {ex.Message}");
                return null;
            }
        }
    }

    public interface IEInvoiceWebService
    {
        Task<ImportInvoiceRes> SendImportInvoice(PagingInfo pagingInfo, int page, string url, string taxCode, ImportInvoiceRequest requestData);
        Task<ImportInvoiceDetailsRes> SendImportInvoiceDetails(PagingInfoDetails pagingInfo, int page, string url, string taxCode, ImportInvoiceDetailsRequest requestData);
    }
}
