﻿using Newtonsoft.Json;
using NLog;
using NLog.Web;
using SSI.RpaEinvoice.Common;
using SSI.RpaEinvoice.Shared.Common;
using SSI.RpaEinvoice.Shared.Domain;
using SSI.RpaEinvoice.Shared.EF;
using SSI.RpaEinvoice.Shared.EF.Repositories;
using SSI.RpaEinvoice.Shared.EInvoiceEntites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SSI.RpaEinvoiceService.Services
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IRpaRepository _rpaRepository;
        private readonly IEInvoiceWebService _eInvoiceWebService;
        private Logger logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

        public InvoiceService(IRpaRepository rpaRepository, IEInvoiceWebService eInvoiceWebService)
        {            
            _rpaRepository = rpaRepository;
            _eInvoiceWebService = eInvoiceWebService;
        }
        
        private async Task<List<API_INV_GetBranch>> GetBranches()
        {
            try
            {
                var res = await _rpaRepository.GetBranchList();
                return res;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
            return null;
        }

        #region Invoices
        public async Task ProcessData()
        {
            //var key = Util.GenerateToken("POST", "api", "U46GpJCO48IX");

            if (!DataStorage.IsOnMonitorProcessInvoice())
            {
                var year = DateTime.Now.AddMonths(-1).Year;
                var month = DateTime.Now.AddMonths(-1).Month;               

                DataStorage.ActionMonth = month;
                DataStorage.ActionYear = year;

                var lstBranch = await GetBranches();
                if (lstBranch != null && lstBranch.Any())
                {
                    foreach (var branch in lstBranch)
                    {
                        (new Thread(() => ProcessBranchData(branch.BranchID, month, year))).Start();
                    }
                }
            }
            else
            {
                logger.Info("Previous process is running!");
            }
        }

        private async Task<PagingInfo> GetPagingInfo(string branchId, int month, int year)
        {
            try
            {
                var res = await _rpaRepository.GetPagingInfo(month, year, branchId);
                return res;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
            return null;
        }

        private async Task<InvoicesToTransfer> GetInvoicesToTransfer(string branchID, int month, int year, int rowsOfPage, int page)
        {
            try
            {
                var res = await _rpaRepository.GetInvoicesToTransfer(month, year, branchID, rowsOfPage, page);
                return res;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
            return null;
        }

        private async void ProcessBranchData(string branchID, int month, int year)
        {
            try
            {
                var pagingInfo = await GetPagingInfo(branchID, month, year);
                if (pagingInfo != null && pagingInfo.RowsOfPage > 0)
                {
                    DataStorage.UpdateMonitorProcessInvoice(branchID, true);
                    for (int i = 1; i <= pagingInfo.TotPage; i++)
                    {
                        var data = await GetInvoicesToTransfer(branchID, month, year, pagingInfo.RowsOfPage, i);
                        if (data != null && !string.IsNullOrEmpty(data.XmlData))
                        {
                            await SendDataToInvoice(data, i, pagingInfo);
                        }
                    }
                    DataStorage.UpdateMonitorProcessInvoice(branchID, false);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message.ToString());
            }
        }

        public async Task SendDataToInvoice(InvoicesToTransfer data, int page, PagingInfo pagingInfo)
        {
            var res = await _eInvoiceWebService.SendImportInvoice(pagingInfo, page, data.Url, data.TaxCode, new ImportInvoiceRequest()
            {
                XmlData = data.XmlData,
                Pattern = data.Pattern,
                Serial = data.Serial
            });

            if (res != null)
            {
                if (res.Status == ResStatusCode.SuccessCode)
                {
                    foreach (var invoice in res.Data.Invoices)
                    {
                        var jsonInvoice = JsonConvert.SerializeObject(invoice);
                        var invoiceToUpdate = JsonConvert.DeserializeObject<InvoiceToUpdate>(jsonInvoice);
                        invoiceToUpdate.Message = res.Message;
                        invoiceToUpdate.ErrorCode = res.ErrorCode;
                        invoiceToUpdate.Status = res.Status;
                        DataStorage.IkeyInvoices.Enqueue(invoiceToUpdate);
                    }
                }
                else
                {
                    if (res.Data.KeyInvoiceMsg != null && res.Data.KeyInvoiceMsg.Any())
                    {
                        foreach (var invoice in res.Data.KeyInvoiceMsg)
                        {
                            var invoiceToUpdate = new InvoiceToUpdate()
                            {
                                Ikey = invoice.Key,
                                ErrorMsg = invoice.Value,
                                Message = res.Message,
                                ErrorCode = res.ErrorCode,
                                Status = res.Status,
                            };
                            DataStorage.IkeyInvoices.Enqueue(invoiceToUpdate);
                        }
                    }
                }
                logger.Info($"Response from EInvoice with data {JsonConvert.SerializeObject(pagingInfo)}:page={page} is {JsonConvert.SerializeObject(res)}");
            }
        }

        public async Task MonitorRes()
        {
            while (true)
            {
                try
                {
                    InvoiceToUpdate invoice;
                    DataStorage.IkeyInvoices.TryDequeue(out invoice);
                    if (invoice != null)
                    {
                        await UpdateInvoiceToDB(invoice);
                    }
                    else
                    {
                        Thread.Sleep(1000);
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(ex.Message.ToString());
                }
            }
        }

        private async Task<UpdateStatusInvoiceRes> UpdateInvoiceToDB(InvoiceToUpdate invoice)
        {
            int retry = 1;
            bool updateSuccess = false;
            do
            {
                try
                {
                    var res = await _rpaRepository.UpdateInvoice(
                    DataStorage.ActionMonth,
                    DataStorage.ActionYear,
                    invoice.Ikey,
                    invoice.Status,
                    invoice.Message,
                    invoice.ErrorCode.ToString(),
                    invoice.InvoiceStatus.ToString(),
                    invoice.Pattern,
                    invoice.Serial,
                    invoice.No,
                    invoice.LookupCode,
                    invoice.ArisingDate,
                    invoice.IssueDate,
                    invoice.ErrorMsg);

                    if (res == null)
                    {
                        retry++;
                        Thread.Sleep(1000);
                    }
                    else
                    {
                        updateSuccess = true;
                        logger.Info($"Time: {retry}: Update ikey {invoice.Ikey} res: {JsonConvert.SerializeObject(res)}");
                        return res;
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(ex.Message.ToString());
                    logger.Info($"Time: {retry}: Update ikey {invoice.Ikey} res: {ex.Message}");
                }

            } while (retry <= 3 && !updateSuccess);

            return null;
        }
        #endregion

        

    }

    public interface IInvoiceService
    {
        Task ProcessData();        
        Task MonitorRes();        
    }
}
