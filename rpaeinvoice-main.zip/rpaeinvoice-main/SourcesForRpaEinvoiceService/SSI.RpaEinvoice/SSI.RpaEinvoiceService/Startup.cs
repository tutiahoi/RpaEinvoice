﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SSI.RpaEinvoice.Shared.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SSI.RpaEinvoice.Shared.EF.Repositories;
using SSI.RpaEinvoiceService.Services;
using SSI.RpaEinvoice.Common.CustomConfig;

namespace SSI.RpaEinvoiceService
{
    public class Startup
    {        
        public Startup(){}

        public void ConfigureServices(IServiceCollection services)
        {
            var config = LoadConfiguration();
            services.AddSingleton(config);
            services.AddHttpContextAccessor();            
            services.AddHttpClient();

            services.AddSingleton<DbContextFactory>();
            services.AddScoped<IRpaRepository, RpaRepository>();
            services.AddScoped<IEInvoiceWebService, EInvoiceWebService>();

            services.AddScoped<IInvoiceService, InvoiceService>();
            services.AddScoped<IDetailsInvoiceService, DetailsInvoiceService>();
        }

        public static IConfiguration LoadConfiguration()
        {
            return new ConfigurationBuilder().AddProtectedJsonFile("appsettings.json", true).Build(); ;

        }
    }
}
