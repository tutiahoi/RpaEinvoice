﻿using NLog;
using NLog.Web;
using SSI.RpaEinvoiceService.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;

namespace SSI.RpaEinvoiceService
{
    public class TimerServiceRealtime
    {
        private Timer timer = null;

        private Logger logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

        private string section;
        private string timeStart;
        private string timeEnd;
        private int interval;
        private bool runImmediate;

        private IInvoiceService _invoiceService;
        private IDetailsInvoiceService _detailsInvoiceService;

        public TimerServiceRealtime(string _section, bool _enable, string _timeStart, string _timeEnd, int _interval, bool _runImmediate, IInvoiceService invoiceService, IDetailsInvoiceService detailsInvoiceService)
        {
            logger.Info("Creating timer:" + _section);
            //Time config
            section = _section;
            timeStart = _timeStart;
            timeEnd = _timeEnd;
            interval = _interval;
            runImmediate = _runImmediate;

            _invoiceService = invoiceService;
            _detailsInvoiceService = detailsInvoiceService;

            if (_enable)
            {
                if (runImmediate)
                {
                    logger.Info("Section: " + section);
                    timer = new Timer(new TimerCallback(TimerProcess), section, 0, 0);
                }
                else
                {
                    CreateTimer();
                }
                
            }
        }

        public void Disponse()
        {
            if (timer != null)
            {
                timer.Dispose();
                timer = null;
            }
        }

        private void CreateTimer()
        {
            logger.Info("Section: " + section);            
            TimeSpan dueTime = GetDueTime();
            timer = new Timer(new TimerCallback(TimerProcess), section, dueTime, new TimeSpan(24, 0, 0));
            logger.Info("Section: " + section + ", Due time: " + dueTime.Hours.ToString() + ":" + dueTime.Minutes.ToString() + ":" + dueTime.Seconds.ToString());

        }
        private TimeSpan GetDueTime()
        {
            //Lay thoi gian hien tai
            DateTime datetimeNow = DateTime.Now;
            //Thoi gian chay = Thoi gian hien tai + So giay delay
            DateTime datetimeRun = datetimeNow.AddSeconds(interval);
            TimeSpan dueTime = datetimeRun - datetimeNow;
            logger.Info("Timer: " + section + ", Next runtime: " + datetimeRun + ", Due time: " + dueTime.Hours.ToString() + ":" + dueTime.Minutes.ToString() + ":" + dueTime.Seconds.ToString());
            return dueTime;
        }
        private bool CheckTime()
        {
            try
            {                
                string timeNow = DateTime.Now.ToString("HH:mm:ss");
                if ((string.Compare(timeNow, timeStart) >= 0) && (string.Compare(timeEnd, timeNow) >= 0))
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                logger.Error($"Exception " + ex.Message + $"\n details: {JsonConvert.SerializeObject(ex)}");
            }
            return false;
        }

        private async void TimerProcess(object state)
        {
            try
            {
                string timerSession = (string)state;
                logger.Info("Section: " + section);

                switch (timerSession)
                {
                    case "MonitorImportInvoiceFlag":
                        {
                            if (CheckTime())
                            {
                                logger.Info(section + " Start");
                                await _invoiceService.ProcessData();

                                logger.Info(section + " Finnished");
                            }
                        }
                        break;
                    case "MonitorImportInvoiceDetailsFlag":
                        {
                            if (CheckTime())
                            {
                                logger.Info(section + " Start");
                                await _detailsInvoiceService.ProcessData();

                                logger.Info(section + " Finnished");
                            }
                        }
                        break;

                    default:
                        break;
                }
                //Thay doi lai thoi gian chay tiep theo 
                TimeSpan dueTime = GetDueTime();
                logger.Info("Section: " + section + ", Due time: " + dueTime.Hours.ToString() + ":" + dueTime.Minutes.ToString() + ":" + dueTime.Seconds.ToString());
                timer.Change(dueTime, new TimeSpan(24, 0, 0));
            }
            catch (Exception ex)
            {
                logger.Error($"Exception " + ex.Message + $"\n details: {JsonConvert.SerializeObject(ex)}");
            }
        }
    }
}
