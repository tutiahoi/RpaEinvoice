﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SSI.RpaEinvoice.Shared.EF;
using SSI.RpaEinvoice.Shared.EF.Repositories;
using SSI.RpaEinvoiceService.Services;
using System;
using Microsoft.Extensions.Configuration;
using SSI.RpaEinvoiceService;
using SSI.RpaEinvoice.Common.CustomConfig;

namespace SSI.RpaEinvoiceTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var services = new ServiceCollection();
            ConfigureServices(services);
            ServiceProvider serviceProvider = services.BuildServiceProvider();

            Startup app = serviceProvider.GetService<Startup>();
            Console.WriteLine("Starting service.....");
            app.Run();

        }

        public static void ConfigureServices(IServiceCollection services)
        {
            var config = LoadConfiguration();
            services.AddSingleton(config);

            services.AddScoped<Startup>();

            services.AddHttpContextAccessor();
            services.AddHttpClient();

            services.AddSingleton<DbContextFactory>();
            services.AddScoped<IRpaRepository, RpaRepository>();
            services.AddSingleton<IEInvoiceWebService, EInvoiceWebService>();

            services.AddSingleton<IInvoiceService, InvoiceService>();
            services.AddSingleton<IDetailsInvoiceService, DetailsInvoiceService>();

        }

        public static IConfiguration LoadConfiguration()
        {
            return new ConfigurationBuilder().AddProtectedJsonFile("appsettings.json", true).Build();
        }
    }
}
