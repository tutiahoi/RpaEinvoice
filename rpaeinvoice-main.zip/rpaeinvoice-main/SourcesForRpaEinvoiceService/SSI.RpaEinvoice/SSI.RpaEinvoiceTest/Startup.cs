﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SSI.RpaEinvoice.Shared.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SSI.RpaEinvoice.Shared.EF.Repositories;
using SSI.RpaEinvoiceService.Services;
using SSI.RpaEinvoiceService;
using NLog.Web;
using NLog;
using Newtonsoft.Json;
using System.Threading;
using SSI.RpaEinvoice.Common.CustomConfig;

namespace SSI.RpaEinvoiceTest
{
    public class Startup
    {
        private IConfigurationRoot config = new ConfigurationBuilder().AddProtectedJsonFile("appsettings.json", true).Build();        
        private Logger logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();
        private readonly IInvoiceService invoiceService;
        private readonly IDetailsInvoiceService detailsInvoiceService;

        public Startup(IInvoiceService _invoiceService, IDetailsInvoiceService _detailsInvoiceService)
        {
            invoiceService = _invoiceService;
            detailsInvoiceService = _detailsInvoiceService;
        }

        internal void Run()
        {
            logger.Info($"{DateTime.Now} started.{Environment.NewLine}");
            
            (new Thread(() => invoiceService.MonitorRes())).Start();
            (new Thread(() => detailsInvoiceService.MonitorRes())).Start();

            var valuesSection = config.GetSection("JobConfig:Values");
            try
            {
                foreach (IConfigurationSection section in valuesSection.GetChildren())
                {
                    if (section.GetValue<string>("JobName") == "MonitorImportInvoiceFlag")
                    {
                        TimerServiceRealtime timer = new TimerServiceRealtime(section.GetValue<string>("JobName"),
                                                                        section.GetValue<bool>("Enable"),
                                                                        section.GetValue<string>("Time.Start"),
                                                                        section.GetValue<string>("Time.End"),
                                                                        section.GetValue<int>("Interval"),
                                                                        section.GetValue<bool>("RunImmediate"),
                                                                        invoiceService, detailsInvoiceService);
                        logger.Info("JobStart: " + section.GetValue<string>("JobName"));
                    }
                    else if (section.GetValue<string>("JobName") == "MonitorImportInvoiceDetailsFlag")  
                    {
                        TimerServiceRealtime timer = new TimerServiceRealtime(section.GetValue<string>("JobName"),
                                                                        section.GetValue<bool>("Enable"),
                                                                        section.GetValue<string>("Time.Start"),
                                                                        section.GetValue<string>("Time.End"),
                                                                        section.GetValue<int>("Interval"),
                                                                        section.GetValue<bool>("RunImmediate"),
                                                                        invoiceService, detailsInvoiceService);
                        logger.Info("JobStart: " + section.GetValue<string>("JobName"));
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("Exception " + ex.Message + $"\n detail: {JsonConvert.SerializeObject(ex)}");
            }
            Console.ReadLine();
        }
    }
}
